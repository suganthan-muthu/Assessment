﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MailDIR.Services.contract
{
    public interface IImportToSQLRepo
    {
        void ImportToSQL();
    }
}
